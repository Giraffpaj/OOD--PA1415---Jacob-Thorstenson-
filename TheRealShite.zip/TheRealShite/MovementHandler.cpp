#include "MovementHandler.h"

MovementHandler::MovementHandler(Library*myLibrary)
{
	this->myLibrary = myLibrary;
	this->myMoveEvents = new ArrayList<Event>(20);
	//load Texture
	//if (!this->playerTexture.loadFromFile("spritesheet.png"))
	//{
	//	EXIT_FAILURE; 
	//}
	////set sprite
	//this->playerSprite.setTexture(this->playerTexture); 
	//
	////set hitbox to same size as sprite
	//this->playerRect.setSize(sf::Vector2f(32, 32)); 


	//this->playerSprite.setTextureRect(sf::IntRect(this->counterWalking * 32, 0, 32, 32));

	

}

void MovementHandler::addEvent(Event*myEvent)
{
	this->myMoveEvents->add(myEvent);
}

void MovementHandler::tick()
{
	Event*currentEvent;
	Player*thePlayer = this->myLibrary->getPlayer(0);
	for (int a = 0; a < this->myMoveEvents->getSize(); a++)
	{
		currentEvent = this->myMoveEvents->getData(a);
		if (currentEvent->getAction() == "moveUp")
		{
			//Player g�r Upp
			thePlayer->updateSpriteSheet(this->counterWalking, 3, 0, -1);
		}
		if (currentEvent->getAction() == "moveRight")
		{
			//Player g�r H�ger
			thePlayer->updateSpriteSheet(this->counterWalking, 2, 1, 0);
		}
		if (currentEvent->getAction() == "moveDown")
		{
			//Player g�r ner
			thePlayer->updateSpriteSheet(this->counterWalking, 0, 0, 1);
		}
		if (currentEvent->getAction() == "moveLeft")
		{
			//Player g�r v�nster
			thePlayer->updateSpriteSheet(this->counterWalking, 1, -1, 0);
		}
		this->counterWalking++;
		if (this->counterWalking == 2)
		{
			this->counterWalking = 0;
		}
		this->myMoveEvents->remove(currentEvent);
	}

}

//void MovementHandler::combat()
//{
//	if (direction == 1 && sf::Keyboard().isKeyPressed(sf::Keyboard::Space))
//	{
//		this->playerSprite.setTextureRect(sf::IntRect(0, 7 * 32, 32, 32));
//	}
//	if (direction == 2 && sf::Keyboard().isKeyPressed(sf::Keyboard::Space))
//	{
//		this->playerSprite.setTextureRect(sf::IntRect(0, 4 * 32, 32, 32));
//	}
//	if (direction == 3 && sf::Keyboard().isKeyPressed(sf::Keyboard::Space))
//	{
//		this->playerSprite.setTextureRect(sf::IntRect(0, 5 * 32, 32, 32));
//	}
//	if (direction == 4 && sf::Keyboard().isKeyPressed(sf::Keyboard::Space))
//	{
//		this->playerSprite.setTextureRect(sf::IntRect(0, 6 * 32, 32, 32));
//	}
//
//}
